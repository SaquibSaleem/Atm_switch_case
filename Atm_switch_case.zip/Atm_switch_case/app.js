let ATM = +prompt("1: Pin  2: Cash with draw  3: Enter the Amout  4: Take Recepit  5: Take Your Card  6:Thank You")
switch (ATM) {
    case 1:
    alert("Pin code");
    break;
    case 2:
    alert("Cash With draw");
    break;
    case 3:
    alert("Enter the Amout");
    break;
    case 4:
    alert("Take Receipt");
    break;
    case 5:
    alert("Take your Card");
    break;
    case 6:
    alert("Thank You");
    break;
    default:
    alert("Transition failed")
    break;
}